<?php
return [
    'host' => 'localhost',
    'dbname' => 'tpanel',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4'
];
